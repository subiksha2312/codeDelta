package com.example.gdow

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

var truescore:Int=0
class gameView1 : AppCompatActivity() {
    var objDOW = GuessDOW();
    var nOptions = IntArray(4)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_view1)

        objDOW.generateDt()
        val DisplayDate: String = objDOW.DecoratedDate()

        var btnCheck = findViewById(R.id.btnCheck) as Button
        btnCheck.setOnClickListener {
            onClickCheckAnswer()
        }
        var text: TextView = findViewById(R.id.textView2) as TextView
        text.setText(DisplayDate)

        objDOW.RandomDows()
        val WeekArray = arrayOf<String>(
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        )
        nOptions = objDOW.RandomDows()

        val radio1 = findViewById(R.id.Option1) as RadioButton
        val radio2 = findViewById(R.id.Option2) as RadioButton
        val radio3 = findViewById(R.id.Option3) as RadioButton
        val radio4 = findViewById(R.id.Option4) as RadioButton

        radio1.setText(WeekArray[nOptions[0]])
        radio2.setText(WeekArray[nOptions[1]])
        radio3.setText(WeekArray[nOptions[2]])
        radio4.setText(WeekArray[nOptions[3]])


    }

    fun openGameView2(currscore:Int) {
        val intent = Intent(this, GameView2::class.java)
        intent.putExtra("score",currscore)
        startActivity(intent)
    }

    fun openGameView1() {
        val intent = Intent(this, gameView1::class.java)
        startActivity(intent)
    }

    fun onClickCheckAnswer() {
        var btnCheck = findViewById(R.id.btnCheck) as Button
        // Get the checked radio button id from radio group
        var radioGroup = findViewById(R.id.RadioGroup) as RadioGroup
        var id: Int = radioGroup.checkedRadioButtonId
        if (id != -1) { // If any radio button checked from radio group
            // Get the instance of radio button using id
            val radio: RadioButton = findViewById(id)
            val userOption:String = radio.text as String
            if (objDOW.checkanswer(userOption)) {
                truescore++
                openGameView1()
            }
            else {
                // var currscore = objDOW.getscore()
                openGameView2(truescore)
            }


        }
    }
}






            // Get the currently selection Answer
            // findViewById (RadioGroup)
            // find the current radio button selection -- {Option1, Option2, 3, 4}
            // When Option1 -- Call Boolean rightAnswer = CheckAnswer(nOptions[0])
            // if rightAnswer then navigate to GameView1 else GameView2





