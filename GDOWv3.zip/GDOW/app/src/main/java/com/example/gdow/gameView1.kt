package com.example.gdow

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import androidx.constraintlayout.widget.ConstraintLayout
import android.os.VibrationEffect
import android.os.Vibrator


var truescore:Int=0
class gameView1 : AppCompatActivity() {
    var objDOW = GuessDOW();
    var nOptions = IntArray(4)
    var saveddate:String=""
    var savedOp1:String=""
    var savedOp2:String=""
    var savedOp3:String=""
    var savedOp4:String=""

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        saveddate= ((findViewById(R.id.textView2) as TextView).text).toString()

        savedOp1= ((findViewById(R.id.Option1) as TextView).text).toString()
        savedOp2= ((findViewById(R.id.Option2) as TextView).text).toString()
        savedOp3= ((findViewById(R.id.Option3) as TextView).text).toString()
        savedOp4= ((findViewById(R.id.Option4) as TextView).text).toString()

        Log.d("saveddate", saveddate)
        Log.d("savedOp1", savedOp1)
        Log.d("savedOp2", savedOp2)
        Log.d("savedOp3", savedOp3)
        Log.d("savedOp4", savedOp4)

        outState.putString("saveddate",saveddate)
        outState.putString("savedOp1",savedOp1)
        outState.putString("savedOp2",savedOp2)
        outState.putString("savedOp3",savedOp3)
        outState.putString("savedOp4",savedOp4)


    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        var tvDate = findViewById(R.id.textView2) as TextView
        var radio1 = findViewById(R.id.Option1) as RadioButton
        var radio2 = findViewById(R.id.Option2) as RadioButton
        var radio3 = findViewById(R.id.Option3) as RadioButton
        var radio4 = findViewById(R.id.Option4) as RadioButton

        tvDate.setText(savedInstanceState.getString("saveddate"))
        radio1.setText(savedInstanceState.getString("savedOp1"))
        radio2.setText(savedInstanceState.getString("savedOp2"))
        radio3.setText(savedInstanceState.getString("savedOp3"))
        radio4.setText(savedInstanceState.getString("savedOp4"))

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_view1)
        if(truescore>0) {
            var conlayout = findViewById(R.id.gameView1Layout) as ConstraintLayout
            conlayout.setBackgroundResource(R.color.Green)
        }


        objDOW.generateDt()
        val DisplayDate: String = objDOW.DecoratedDate()

        var btnCheck = findViewById(R.id.btnCheck) as Button
        btnCheck.setOnClickListener {
            onClickCheckAnswer()
        }
        var text: TextView = findViewById(R.id.textView2) as TextView
        text.setText(DisplayDate)

        objDOW.RandomDows()
        val WeekArray = arrayOf<String>(
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        )
        nOptions = objDOW.RandomDows()

        val radio1 = findViewById(R.id.Option1) as RadioButton
        val radio2 = findViewById(R.id.Option2) as RadioButton
        val radio3 = findViewById(R.id.Option3) as RadioButton
        val radio4 = findViewById(R.id.Option4) as RadioButton

        radio1.setOnClickListener {
            onRadioButtonClick()
        }
        radio2.setOnClickListener {
            onRadioButtonClick()
        }
        radio3.setOnClickListener {
            onRadioButtonClick()
        }
        radio4.setOnClickListener {
            onRadioButtonClick()
        }

        radio1.setText(WeekArray[nOptions[0]])
        radio2.setText(WeekArray[nOptions[1]])
        radio3.setText(WeekArray[nOptions[2]])
        radio4.setText(WeekArray[nOptions[3]])


    }

    fun onRadioButtonClick() {
        val v = (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(500,
                VibrationEffect.DEFAULT_AMPLITUDE))
        }
        else {
            v.vibrate(500)
        }
    }

    fun openGameView2(currscore:Int) {
        val intent = Intent(this, GameView2::class.java)
        intent.putExtra("score",currscore)
        startActivity(intent)
    }

    fun openGameView1() {
        //var conlayout=findViewById(R.id.gameView1Layout) as ConstraintLayout
        val intent = Intent(this, gameView1::class.java)
        //conlayout.setBackgroundResource(R.color.Green)
        startActivity(intent)
    }

    fun onClickCheckAnswer() {
        //var conlayout=findViewById(R.id.gameView1Layout) as ConstraintLayout
        var btnCheck = findViewById(R.id.btnCheck) as Button
        // Get the checked radio button id from radio group
        var radioGroup = findViewById(R.id.RadioGroup) as RadioGroup
        var id: Int = radioGroup.checkedRadioButtonId
        if (id != -1) { // If any radio button checked from radio group
            // Get the instance of radio button using id
            val radio: RadioButton = findViewById(id)
            val userOption:String = radio.text as String
            if (objDOW.checkanswer(userOption)) {
                truescore++
                //conlayout.setBackgroundResource(R.color.Green)


                openGameView1()
            }
            else {
                // var currscore = objDOW.getscore()
                //conlayout.setBackgroundResource(R.color.Red)
                openGameView2(truescore)
            }


        }
    }
}






            // Get the currently selection Answer
            // findViewById (RadioGroup)
            // find the current radio button selection -- {Option1, Option2, 3, 4}
            // When Option1 -- Call Boolean rightAnswer = CheckAnswer(nOptions[0])
            // if rightAnswer then navigate to GameView1 else GameView2





